angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('giyim', {
    url: '/ page2     ',
    templateUrl: 'templates/giyim.html',
    controller: 'giyimCtrl'
  })

  .state('aramaEkran', {
    url: '/page4',
    templateUrl: 'templates/aramaEkran.html',
    controller: 'aramaEkranCtrl'
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('anasayfa', {
    url: '/page6',
    templateUrl: 'templates/anasayfa.html',
    controller: 'anasayfaCtrl'
  })

  .state('sepetim', {
    url: '/page7',
    templateUrl: 'templates/sepetim.html',
    controller: 'sepetimCtrl'
  })

  .state('faturaBilgileri', {
    url: '/page10',
    templateUrl: 'templates/faturaBilgileri.html',
    controller: 'faturaBilgileriCtrl'
  })

  .state('giris', {
    url: '/page11',
    templateUrl: 'templates/giris.html',
    controller: 'girisCtrl'
  })

  .state('satNAlma', {
    url: '/page12',
    templateUrl: 'templates/satNAlma.html',
    controller: 'satNAlmaCtrl'
  })

  .state('fAVORLER', {
    url: '/page15',
    templateUrl: 'templates/fAVORLER.html',
    controller: 'fAVORLERCtrl'
  })

$urlRouterProvider.otherwise('')


});