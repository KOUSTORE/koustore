angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController.yNETCGR', {
    url: '/page3',
    views: {
      'tab3': {
        templateUrl: 'templates/yNETCGR.html',
        controller: 'yNETCGRCtrl'
      }
    }
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.LEMLER', {
    url: '/page6',
    views: {
      'tab3': {
        templateUrl: 'templates/LEMLER.html',
        controller: 'LEMLERCtrl'
      }
    }
  })

  .state('tabsController.RNEKLE', {
    url: '/page7',
    views: {
      'tab3': {
        templateUrl: 'templates/RNEKLE.html',
        controller: 'RNEKLECtrl'
      }
    }
  })

  .state('tabsController.sELRN', {
    url: '/page8',
    views: {
      'tab3': {
        templateUrl: 'templates/sELRN.html',
        controller: 'sELRNCtrl'
      }
    }
  })

  .state('tabsController.sLMEYONAYLA', {
    url: '/page9',
    views: {
      'tab3': {
        templateUrl: 'templates/sLMEYONAYLA.html',
        controller: 'sLMEYONAYLACtrl'
      }
    }
  })

  .state('tabsController.RNSLND', {
    url: '/page10',
    views: {
      'tab3': {
        templateUrl: 'templates/RNSLND.html',
        controller: 'RNSLNDCtrl'
      }
    }
  })

  .state('tabsController.RNEKLEND', {
    url: '/page11',
    views: {
      'tab3': {
        templateUrl: 'templates/RNEKLEND.html',
        controller: 'RNEKLENDCtrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/page3')


});